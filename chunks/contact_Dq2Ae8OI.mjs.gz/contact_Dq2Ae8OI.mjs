import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import { jsx, jsxs } from 'react/jsx-runtime';
import 'react';
import { T as Theme, C as Container, M as MediaQuery, F as FadeIn, H as HeroSlider1, $ as $$Layout } from './index_DTAwUbTs.mjs';
import styled from '@emotion/styled';
import { T as TextBox, F as Footer } from './index_BD4fk1GS.mjs';
import { H as Hero } from './index_CoLJo8pu.mjs';

const ContactStyled = styled.section`
    background: ${Theme.primary};
    padding-top: 90px;
    border-top-left-radius: 50px;
    border-top-right-radius: 50px;
    margin: -43px 0 90px;
    z-index: 1;
    position: relative;
`;
styled.div`
    max-width: 920px;
    margin: 0 auto;
`;
styled.h2`
    &,
    &:last-child {
        margin-bottom: 90px;
    }
`;
const ContainerStyled = styled(Container)`
    ${MediaQuery.min("xxxl")} {
        max-width: 920px;
    }
`;
const ContactBox = styled.div`
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 40px;
    margin: 40px 0;

    ${MediaQuery.max("lg")} {
        grid-template-columns: 1fr;
    }
`;

const Contact = () => {
  return /* @__PURE__ */ jsx(ContactStyled, { children: /* @__PURE__ */ jsxs(ContainerStyled, { children: [
    /* @__PURE__ */ jsxs(ContactBox, { children: [
      /* @__PURE__ */ jsx(FadeIn, { delay: 0.1, children: /* @__PURE__ */ jsxs(
        TextBox,
        {
          variant: "background-text",
          bgText: "Phone",
          boxAsLink: true,
          href: "tel:+52 123 233 421",
          target: "_blank",
          children: [
            /* @__PURE__ */ jsx("h3", { children: "+52 123 233 421" }),
            /* @__PURE__ */ jsx("p", { children: "you can call me if you have any questions or just want to say hi" })
          ]
        }
      ) }),
      /* @__PURE__ */ jsx(FadeIn, { delay: 0.2, children: /* @__PURE__ */ jsxs(
        TextBox,
        {
          variant: "background-text",
          bgText: "Email",
          boxAsLink: true,
          href: "mailto:youremail@gmail.com",
          target: "_blank",
          children: [
            /* @__PURE__ */ jsx("h3", { children: "youremail@gmail.com" }),
            /* @__PURE__ */ jsx("p", { children: "also you can write me an email if you have any questions" })
          ]
        }
      ) })
    ] }),
    /* @__PURE__ */ jsx(FadeIn, { delay: 0.3, children: /* @__PURE__ */ jsxs(TextBox, { variant: "background-text", bgText: "Address", children: [
      /* @__PURE__ */ jsx("h3", { children: "Address" }),
      /* @__PURE__ */ jsx("p", { children: "Some street 123, 12345 City, Country" }),
      /* @__PURE__ */ jsx("p", { children: "Office: Mystr street 321, 54321 City, Country" })
    ] }) })
  ] }) });
};

const $$Contact = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Cybernetic | Homepage", "description": "YOUR META DESCRIPTION FOR SEO" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "heroType": "ParallaxImage", "client:load": true, "data": {
    image: HeroSlider1.src,
    content: {
      title: "Contact",
      paragraph: "Get stuck or need help? Contact us and we will help you out!"
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "ContactModule", Contact, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/Contact", "client:component-export": "Contact" })} </main> ${renderComponent($$result2, "Footer", Footer, {})} ` })}`;
}, "C:/Users/david/Desktop/David/Projects/mediterrania-arrangements/src/pages/contact.astro", void 0);

const $$file = "C:/Users/david/Desktop/David/Projects/mediterrania-arrangements/src/pages/contact.astro";
const $$url = "/mediterrania-arrangements/contact";

export { $$Contact as default, $$file as file, $$url as url };
