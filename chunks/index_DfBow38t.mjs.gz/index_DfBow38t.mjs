import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import 'react/jsx-runtime';
import 'react';
import { d as BackgroundImg1, a as HeroSlider3, e as HeroSlider2, $ as $$Layout } from './index_DTAwUbTs.mjs';
import { H as Hero } from './index_CoLJo8pu.mjs';

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Mediterr\xE0nia Arrangements | Homepage", "description": "Els millors arranjaments amb aroma Mediterrani" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "client:load": true, "heroType": "fullPageSlider", "data": [
    {
      subtitle: "",
      title: "MEDITERR\xC0NIA \xC9S UNA FESTA",
      background: BackgroundImg1.src,
      paragraph: "",
      button: {
        text: "Anar al lloc",
        link: "https://codexcode.store/themes/cybernetic-website-template"
      }
    },
    {
      subtitle: "",
      title: "UNA CAN\xC7\xD3 SENSE SENTIT",
      background: HeroSlider3.src,
      paragraph: "Descobreix els millors arranjaments amb aroma Mediterrani",
      button: {
        text: "Veure els arranjaments",
        link: "/infinite"
      }
    },
    {
      subtitle: "",
      title: "MEDITERR\xC0NIA \xC9S LA TENDRESA",
      background: HeroSlider2.src,
      paragraph: "Anima't i puja el v\xEDdeo de la teua xaranga interpretant els nostres arranjaments",
      button: {
        text: "COMPARTEIX",
        link: "/infinite"
      }
    },
    {
      subtitle: "",
      title: "MEDITERR\xC0NIA EL NOSTRE CRIT!",
      background: HeroSlider2.src,
      paragraph: "Contacta per obtenir els arranjaments amb les can\xE7ons que vullguis",
      button: {
        text: "CONTACTA",
        link: "/infinite"
      }
    }
  ], "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} </main> ` })}`;
}, "C:/Users/david/Desktop/David/Projects/mediterrania-arrangements/src/pages/index.astro", void 0);

const $$file = "C:/Users/david/Desktop/David/Projects/mediterrania-arrangements/src/pages/index.astro";
const $$url = "/mediterrania-arrangements";

export { $$Index as default, $$file as file, $$url as url };
